import React from 'react';

function Sobre(){
    return(
        <div>
            <h1>Banco Digital SoulBank</h1>
            <span>Voçê Com A Gente Sempre</span>
            <br/>
            
        </div>
    )
}
export default Sobre;