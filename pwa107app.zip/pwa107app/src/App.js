/**-------------------------------------------------*
 *       SENAC - TADS - Programação Web             *                
 *    Aula #06  Trabalhando As Rotas e LINKS        *
 *--------------------------------------------------*/
 import RoutesApp from "./routes";
 import React from 'react';
 
 function App() {
  
   return (
     <div>
      <RoutesApp/>
      </div>
   );
 
   }
 
 export default App;
 